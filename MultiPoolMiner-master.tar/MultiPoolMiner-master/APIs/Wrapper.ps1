﻿using module ..\Include.psm1

class Wrapper : Miner {
}