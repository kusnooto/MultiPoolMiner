# Try running this script as:  http://localhost:3999/scripts/demo.ps1?message=Hello%20World!

param($Parameters)
Write-Output $Parameters.message