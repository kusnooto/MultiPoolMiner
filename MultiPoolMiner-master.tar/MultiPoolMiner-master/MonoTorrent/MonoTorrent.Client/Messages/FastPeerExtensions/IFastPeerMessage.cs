namespace MonoTorrent.Client.Messages.FastPeer
{
    using System;
    using System.Collections.Generic;
    using System.Text;

    interface IFastPeerMessage
    {
    }
}
