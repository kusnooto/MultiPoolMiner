namespace MonoTorrent.Client
{
    using System;
    using System.Text;

    public class StatsUpdateEventArgs : EventArgs
    {
        public StatsUpdateEventArgs()
        {
        }
    }
}
